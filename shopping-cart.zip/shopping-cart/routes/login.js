const express = require('express');
const bodyParser = require('body-parser');
const jsonParser = bodyParser.json();
const router = express.Router();
const sqlite3 = require('sqlite3').verbose();
const sha256 = require('sha-256-js');
const cookieSession = require('cookie-session');
const db = new sqlite3.Database( __dirname + '/users.db',
    function(err) {
        if ( !err ) {
            db.run(`
                CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                password TEXT,
                FName TEXT,
                LName TEXT,
                Email TEXT
            )`);
            console.log('opened users.db');
        }
    });
const allowed_pages = [
    '/login.html',
    '/register.html'
];

router.use(cookieSession({
    name: 'session',
    secret: 'foo'
    }));

router.get('/', function(req, res) {
    res.type('.html');
    res.redirect('login.html');
});

router.post('/login.html',jsonParser, function(req, res) {
    const u = req.body;
    console.log(u);
    if(u.submit == 'Login'){
    db.get('SELECT * FROM users WHERE username = ?',
        [ u.username ],
        function(err, row) {
            console.log(row);
            if ( !err ) {
                console.log('no err');
                if( row ) {
                    console.log('row checked');
                    if( sha256(u.password) == row.password ) {
                        req.session.auth = true;
                        req.session.user = u.user;
                        res.send( JSON.stringify({ ok: true }) );
                    }
                    else {
                        req.session.auth = false;
                        res.send( JSON.stringify({ ok: false }) );
                    }
                }
                else { 
                    req.session.auth = false;
                    res.send( JSON.stringify({ ok: false, msg : 'nouser' }) );
                }
            }
            else {
                req.session.auth = false;
                res.send( err );
            }
        } );
    }
    if(u.submit == "Register"){
        res.redirect('register.html');
    }
    else{
        console.log('err')
    }
});

router.get('/register.html',function(req,res){
    res.type('.html');
    res.redirect('register.html');
});


router.post('/register.html',jsonParser, function(req, res) {
    var u = req.body;
    db.run('INSERT INTO users(username,password,FName,LName,email) VALUES(?,?,?,?,?);',[u.username,sha256(u.password),u.firstName,u.lastName,u.email]);
    console.log('inserted');
    res.redirect('login.html');
});
module.exports = router;